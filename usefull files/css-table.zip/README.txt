A Pen created at CodePen.io. You can find this one at http://codepen.io/cssparadise/pen/NgaOqm.

 Using CSS to fade-in a row, fade-out a row and show data in the table updating on a live basis. Also hovering over a row expands to show more information.